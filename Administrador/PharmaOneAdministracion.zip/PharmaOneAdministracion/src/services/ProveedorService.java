package services;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class ProveedorService {

    public static String listar() throws Exception {
        return Api.get("proveedor/listar");
    }

    public static String crear(String nombre, String telefono,
                               String correo, String direccion) throws Exception {

        String json = String.format("""
            {
                "nombre": "%s",
                "telefono": "%s",
                "correo": "%s",
                "direccion": "%s"
            }
        """, nombre, telefono, correo, direccion);

        return Api.post("proveedor/crear", json);
    }

    public static String buscar(String nombre) throws Exception {
        String nombreCodificado = URLEncoder.encode(nombre, StandardCharsets.UTF_8);
        return Api.get("proveedor/buscar?nombre=" + nombreCodificado);
    }

    public static String editar(int id, String nombre, String telefono,
                                String correo, String direccion) throws Exception {

        String json = String.format("""
            {
                "nombre": "%s",
                "telefono": "%s",
                "correo": "%s",
                "direccion": "%s"
            }
        """, nombre, telefono, correo, direccion);

        return Api.put("proveedor/editar/" + id, json);
    }
}