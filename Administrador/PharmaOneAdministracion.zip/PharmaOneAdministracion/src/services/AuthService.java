package services;

import com.google.gson.Gson;
import Models.LoginResponse;

public class AuthService {

    public static LoginResponse login(String usuario, String password) throws Exception {
        String json = String.format("""
            {
                "usuarioNombre": "%s",
                "password": "%s"
            }
        """, usuario, password);

        String response = Api.post("auth/login", json);

        if (response == null) {
            return null;
        }

        Gson gson = new Gson();
        return gson.fromJson(response, LoginResponse.class);
    }
}