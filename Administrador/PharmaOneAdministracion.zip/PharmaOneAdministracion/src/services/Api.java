package services;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;

public class Api {
    private static final String BASE_URL = "http://localhost:5221/api/";
    public static String get(String endpoint) throws Exception {
        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpGet request = new HttpGet(BASE_URL + endpoint);
        CloseableHttpResponse response = httpClient.execute(request);
        int status = response.getStatusLine().getStatusCode();
        String result = response.getEntity() != null
                ? EntityUtils.toString(response.getEntity())
                : "";
        if (status != 200) {
            System.out.println("ERROR GET " + endpoint + " -> " + status);
            System.out.println(result);
        }
        response.close();
        httpClient.close();
        return result;
    }
    
    public static String post(String endpoint, String json) throws Exception {
        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpPost request = new HttpPost(BASE_URL + endpoint);
        request.setHeader("Content-Type", "application/json");
        request.setEntity(new StringEntity(json));
        CloseableHttpResponse response = httpClient.execute(request);
        int status = response.getStatusLine().getStatusCode();
        String result = response.getEntity() != null
                ? EntityUtils.toString(response.getEntity())
                : "";
        if (status != 200 && status != 201) {
            System.out.println("ERROR POST " + endpoint + " -> " + status);
            System.out.println(result);
        }
        response.close();
        httpClient.close();
        return result;
    }

    public static String put(String endpoint, String json) throws Exception {

        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpPut request = new HttpPut(BASE_URL + endpoint);

        request.setHeader("Content-Type", "application/json");

        if (json != null && !json.isEmpty()) {
            request.setEntity(new StringEntity(json));
        }

        CloseableHttpResponse response = httpClient.execute(request);

        int status = response.getStatusLine().getStatusCode();

        String result = response.getEntity() != null
                ? EntityUtils.toString(response.getEntity())
                : "";

        if (status != 200) {
            System.out.println("ERROR PUT " + endpoint + " -> " + status);
            System.out.println(result);
        }

        response.close();
        httpClient.close();

        return result;
    }

    public static String delete(String endpoint) throws Exception {

        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpDelete request = new HttpDelete(BASE_URL + endpoint);

        CloseableHttpResponse response = httpClient.execute(request);

        int status = response.getStatusLine().getStatusCode();

        String result = response.getEntity() != null
                ? EntityUtils.toString(response.getEntity())
                : "";

        if (status != 200 && status != 204) {
            System.out.println("ERROR DELETE " + endpoint + " -> " + status);
            System.out.println(result);
        }

        response.close();
        httpClient.close();

        return result;
    }
}