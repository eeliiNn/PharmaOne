package services;
import com.google.gson.Gson;
import java.net.URL;
import java.net.HttpURLConnection;
import java.util.HashMap;
import java.util.Map;


public class ProductoService {

    public static String inventarioAdmin() throws Exception {
        return Api.get("producto/inventario-admin");
    }

    public static String listar() throws Exception {
        return Api.get("producto/listar");
    }

    public static String crear(
                String nombre,
                String descripcion,
                double precio,
                boolean receta,
                int categoriaId,
                String foto
        ) throws Exception {

            Map<String, Object> data = new HashMap<>();

            data.put("nombre", nombre);
            data.put("descripcion", descripcion);
            data.put("precioVenta", precio);
            data.put("requiereReceta", receta);
            data.put("categoriaId", categoriaId);
            data.put("foto", foto);

            String json = new Gson().toJson(data);

            return Api.post("producto/crear", json);
        }

    public static String editar(int id,
                                String nombre,
                                String descripcion,
                                double precio,
                                boolean requiereReceta,
                                int categoriaId,
                                String foto) throws Exception {

        String json = String.format("""
            {
                "nombre": "%s",
                "descripcion": "%s",
                "precioVenta": %s,
                "requiereReceta": %s,
                "categoriaId": %s,
                "foto": "%s"
            }
        """,
            nombre,
            descripcion,
            precio,
            requiereReceta,
            categoriaId,
            foto
        );

        return Api.put("producto/editar/" + id, json);
    }

    public static String desactivar(int id) throws Exception {
        return Api.put("producto/desactivar/" + id, "{}");
    }
    
    public static String activar(int id) {
        try {
            return Api.put("producto/activar/" + id, "");
        } catch (Exception e) {
            e.printStackTrace();
            return "Error al activar producto";
        }
    }
}