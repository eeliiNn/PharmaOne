package services;

public class UsuarioService {
    public static String listar() throws Exception {
        return Api.get("usuarios");
    }
    
    public static String crear(String usuario, String password, int rolId) throws Exception {
        String json = "{"
                + "\"usuarioNombre\":\"" + usuario + "\","
                + "\"password\":\"" + password + "\","
                + "\"rolId\":" + rolId
                + "}";

        return Api.post("usuarios", json);
    }
    
    public static String eliminar(int id) throws Exception{
        return Api.delete("usuarios/" + id);
    }
}
