package services;

public class CategoriaService {

    public static String listar() throws Exception {
        return Api.get("categoria/listar");
    }
}