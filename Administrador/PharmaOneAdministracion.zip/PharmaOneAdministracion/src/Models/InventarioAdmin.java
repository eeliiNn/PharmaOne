package Models;

public class InventarioAdmin {

    private int productoId;
    private String nombre;
    private String descripcion;
    private double precioVenta;
    private boolean requiereReceta;
    private boolean estado;
    private String categoria;
    private int categoriaId;
    private int stock;
    private int minimo;
    private String foto;

    public int getProductoId() { return productoId; }
    public String getNombre() { return nombre; }
    public String getDescripcion() { return descripcion; }
    public double getPrecioVenta() { return precioVenta; }
    public boolean isRequiereReceta() { return requiereReceta; }
    public boolean isEstado() { return estado; }
    public String getCategoria() { return categoria; }
    public int getCategoriaId() { return categoriaId; }
    public int getStock() { return stock; }
    public int getMinimo() { return minimo; }
    public String getFoto() { return foto; }
}