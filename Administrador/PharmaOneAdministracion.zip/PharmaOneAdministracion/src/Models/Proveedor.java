package Models;

public class Proveedor {

    private int proveedorId;
    private String nombre;
    private String telefono;
    private String correo;
    private String direccion;

    public int getProveedorId() { return proveedorId; }
    public String getNombre() { return nombre; }
    public String getTelefono() { return telefono; }
    public String getCorreo() { return correo; }
    public String getDireccion() { return direccion; }
    @Override
    public String toString(){
        return nombre;
    }
}