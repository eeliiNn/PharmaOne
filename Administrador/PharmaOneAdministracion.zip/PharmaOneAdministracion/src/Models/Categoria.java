package Models;

public class Categoria {

    private int categoriaId;
    private String nombreCategoria;

    public int getCategoriaId() {
        return categoriaId;
    }

    public String getNombreCategoria() {
        return nombreCategoria;
    }

    @Override
    public String toString() {
        return nombreCategoria;
    }
}
