package Models;

public class Usuario {
    private int usuarioId;
    private String usuarioNombre;
    private String rol;
    
    public int getUsuarioId() { return usuarioId; }
    public String getUsuarioNombre() { return usuarioNombre; }
    public String getRol() { return rol; }
    
    @Override
    public String toString() {
        return usuarioNombre + " (" + rol + ")";
    }
}
