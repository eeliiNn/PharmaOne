package Models;

public class LoginResponse {

    private int usuarioId;
    private String usuarioNombre;
    private String rol;

    public int getUsuarioId() { return usuarioId; }
    public String getUsuarioNombre() { return usuarioNombre; }
    public String getRol() { return rol; }
}