package views;
import Models.InventarioAdmin;
import Models.LoginResponse;
import java.awt.Color;
import java.awt.Image;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.List;
import services.ProductoService;
import Models.Categoria;
import services.CategoriaService;

public class InventarioPanel extends javax.swing.JFrame {
    private LoginResponse usuarioLogueado;
    private int productoSeleccionadoId = -1;
    private javax.swing.JLabel lblImagen;
    private List<InventarioAdmin> listaGlobal;
    
    public InventarioPanel(LoginResponse usuario) {
        initComponents();
        this.usuarioLogueado = usuario;
        getContentPane().setBackground(Color.WHITE);
        setLocationRelativeTo(null);

        lblImagen = new javax.swing.JLabel();
        lblImagen.setPreferredSize(new java.awt.Dimension(120,120));

        categoriaSeleccionadaId.removeAllItems();
        categoriaSeleccionadaId.setModel(new javax.swing.DefaultComboBoxModel<>());

        jTable1.setModel(new DefaultTableModel(
            new Object [][] {},
            new String [] {
                "ID", "Nombre", "Precio", "Receta", "Estado",
                "Categoria", "Stock", "Minimo"
            }
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        });

        jTable1.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && jTable1.getSelectedRow() != -1 && listaGlobal != null) {

                int fila = jTable1.getSelectedRow();
                InventarioAdmin p = listaGlobal.get(fila);

                productoSeleccionadoId = p.getProductoId();

                txtNombre.setText(p.getNombre());
                txtDescripcion.setText(p.getDescripcion());
                txtPrecio.setText(String.valueOf(p.getPrecioVenta()));
                txtFoto.setText(p.getFoto());
                chkReceta.setSelected(p.isRequiereReceta());

                for (int i = 0; i < categoriaSeleccionadaId.getItemCount(); i++) {
                    Categoria c = categoriaSeleccionadaId.getItemAt(i);
                    if (c.getCategoriaId() == p.getCategoriaId()) {
                        categoriaSeleccionadaId.setSelectedIndex(i);
                        break;
                    }
                }

                mostrarImagen(p.getFoto());
                
                if (p.isEstado()) {
                    btnActivar.setEnabled(false);
                    btnDesactivar.setEnabled(true);
                } else {
                    btnActivar.setEnabled(true);
                    btnDesactivar.setEnabled(false);
                }
            }
        });

        cargarCategorias();
        cargarInventario();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        txtDescripcion = new javax.swing.JTextField();
        txtPrecio = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        categoriaSeleccionadaId = new javax.swing.JComboBox<>();
        chkReceta = new javax.swing.JCheckBox();
        jLabel5 = new javax.swing.JLabel();
        txtFoto = new javax.swing.JTextField();
        btnGuardar = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnDesactivar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnRegresar = new javax.swing.JButton();
        btnActivar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(93, 115, 126));
        jLabel1.setText("Nombre:");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(93, 115, 126));
        jLabel2.setText("Descripción:");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(93, 115, 126));
        jLabel3.setText("Precio:");

        txtNombre.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(93, 115, 126)));
        txtNombre.setName("txtNombre"); // NOI18N

        txtDescripcion.setToolTipText("");
        txtDescripcion.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(93, 115, 126)));
        txtDescripcion.setName("txtDescripcion"); // NOI18N

        txtPrecio.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(93, 115, 126)));
        txtPrecio.setName("txtPrecio"); // NOI18N

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(93, 115, 126));
        jLabel4.setText("Categoría:");

        categoriaSeleccionadaId.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(93, 115, 126)));
        categoriaSeleccionadaId.setName("categoriaSeleccionadaId"); // NOI18N

        chkReceta.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        chkReceta.setForeground(new java.awt.Color(93, 115, 126));
        chkReceta.setText("Requiere Receta");
        chkReceta.setActionCommand("chkReceta");
        chkReceta.setName("chkReceta"); // NOI18N
        chkReceta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkRecetaActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(93, 115, 126));
        jLabel5.setText("URL Foto:");

        txtFoto.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(93, 115, 126)));
        txtFoto.setName("txtFoto"); // NOI18N

        btnGuardar.setBackground(new java.awt.Color(93, 115, 126));
        btnGuardar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnGuardar.setForeground(new java.awt.Color(255, 255, 255));
        btnGuardar.setText("Guardar");
        btnGuardar.setName("btnGuardar"); // NOI18N
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnEditar.setBackground(new java.awt.Color(93, 115, 126));
        btnEditar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnEditar.setForeground(new java.awt.Color(255, 255, 255));
        btnEditar.setText("Editar");
        btnEditar.setName("btnEditar"); // NOI18N
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnDesactivar.setBackground(new java.awt.Color(93, 115, 126));
        btnDesactivar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnDesactivar.setForeground(new java.awt.Color(255, 255, 255));
        btnDesactivar.setText("Desactivar");
        btnDesactivar.setName("btnDesactivar"); // NOI18N
        btnDesactivar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDesactivarActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        btnRegresar.setBackground(new java.awt.Color(102, 0, 0));
        btnRegresar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnRegresar.setForeground(new java.awt.Color(255, 255, 255));
        btnRegresar.setText("X");
        btnRegresar.setBorder(null);
        btnRegresar.setName("btnRegresar"); // NOI18N
        btnRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresarActionPerformed(evt);
            }
        });

        btnActivar.setBackground(new java.awt.Color(93, 115, 126));
        btnActivar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnActivar.setForeground(new java.awt.Color(255, 255, 255));
        btnActivar.setText("Activar");
        btnActivar.setName("btnActivar"); // NOI18N
        btnActivar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActivarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(chkReceta)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 91, Short.MAX_VALUE)
                                            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(txtNombre)
                                            .addComponent(txtDescripcion)
                                            .addComponent(txtPrecio)
                                            .addComponent(categoriaSeleccionadaId, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtFoto)))
                                    .addComponent(btnGuardar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnEditar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnDesactivar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addComponent(btnActivar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnRegresar, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(txtDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(chkReceta)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(categoriaSeleccionadaId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(txtFoto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(btnGuardar)
                        .addGap(18, 18, 18)
                        .addComponent(btnEditar)
                        .addGap(18, 18, 18)
                        .addComponent(btnDesactivar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnActivar))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnRegresar)
                        .addGap(1, 1, 1)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(7, Short.MAX_VALUE))
        );

        txtNombre.getAccessibleContext().setAccessibleName("txtNombre");
        txtDescripcion.getAccessibleContext().setAccessibleName("txtDescripcion");
        txtPrecio.getAccessibleContext().setAccessibleName("txtPrecio");
        categoriaSeleccionadaId.getAccessibleContext().setAccessibleName("categoriaSeleccionadaId");
        chkReceta.getAccessibleContext().setAccessibleName("chkReceta");
        txtFoto.getAccessibleContext().setAccessibleName("txtFoto");
        btnGuardar.getAccessibleContext().setAccessibleName("btnGuardar");
        btnEditar.getAccessibleContext().setAccessibleName("btnEditar");
        btnDesactivar.getAccessibleContext().setAccessibleName("btnDesactivar");
        btnActivar.getAccessibleContext().setAccessibleName("btnActivar");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void chkRecetaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkRecetaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chkRecetaActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        // TODO add your handling code here:
         try {
            Categoria categoriaSeleccionada = (Categoria) categoriaSeleccionadaId.getSelectedItem();
            int categoriaId = categoriaSeleccionada.getCategoriaId();
            String response;
             response = ProductoService.crear(
                     txtNombre.getText(),
                     txtDescripcion.getText(),
                     Double.parseDouble(txtPrecio.getText()),
                     chkReceta.isSelected(),
                     categoriaId,
                     txtFoto.getText()
             );
            JOptionPane.showMessageDialog(this, response);
            cargarInventario();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        // TODO add your handling code here:
        if (productoSeleccionadoId == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un producto");
            return;
        }

        try {

            Categoria categoriaSeleccionada = (Categoria) categoriaSeleccionadaId.getSelectedItem();
            int categoriaId = categoriaSeleccionada.getCategoriaId();

            String response = ProductoService.editar(
                    productoSeleccionadoId,
                    txtNombre.getText(),
                    txtDescripcion.getText(),
                    Double.parseDouble(txtPrecio.getText()),
                    chkReceta.isSelected(),
                    categoriaId,
                    txtFoto.getText()
            );

            JOptionPane.showMessageDialog(this, response);
            cargarInventario();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnDesactivarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDesactivarActionPerformed
        // TODO add your handling code here:
        if (productoSeleccionadoId == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un producto");
            return;
        }

        try {
            ProductoService.desactivar(productoSeleccionadoId);
            cargarInventario();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnDesactivarActionPerformed

    private void btnRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresarActionPerformed
        // TODO add your handling code here:
        this.dispose();
        new AdminPanel(usuarioLogueado).setVisible(true);
    }//GEN-LAST:event_btnRegresarActionPerformed

    private void btnActivarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActivarActionPerformed
         if (productoSeleccionadoId == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un producto");
            return;
        }

        try {
            ProductoService.activar(productoSeleccionadoId);

            JOptionPane.showMessageDialog(this, "Producto activado correctamente");

            cargarInventario();

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al activar producto");
        }
    }//GEN-LAST:event_btnActivarActionPerformed

    private void cargarInventario() {
        try {
            String json = ProductoService.inventarioAdmin();
            Gson gson = new Gson();

            InventarioAdmin[] array = gson.fromJson(json, InventarioAdmin[].class);

            if (array == null) {
                listaGlobal = new java.util.ArrayList<>();
            } else {
                listaGlobal = java.util.Arrays.asList(array);
            }

            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            model.setRowCount(0);

            for (InventarioAdmin p : listaGlobal) {
                model.addRow(new Object[]{
                    p.getProductoId(),
                    p.getNombre(),
                    p.getPrecioVenta(),
                    p.isRequiereReceta() ? "Sí" : "No",
                    p.isEstado() ? "Activo" : "Inactivo",
                    p.getCategoria(),
                    p.getStock(),
                    p.getMinimo()
                });
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void mostrarImagen(String url) {
        try {
            URL imageUrl = new URL(url);
            ImageIcon icon = new ImageIcon(imageUrl);

            Image img = icon.getImage().getScaledInstance(
                    lblImagen.getWidth(),
                    lblImagen.getHeight(),
                    Image.SCALE_SMOOTH
            );

            lblImagen.setIcon(new ImageIcon(img));

        } catch (Exception e) {
            lblImagen.setIcon(null);
        }
    }
    
    private void cargarCategorias() {
        try {

            String json = CategoriaService.listar();
            Gson gson = new Gson();

            Categoria[] categorias = gson.fromJson(json, Categoria[].class);

            categoriaSeleccionadaId.removeAllItems();

            for (Categoria c : categorias) {
                categoriaSeleccionadaId.addItem(c);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InventarioPanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InventarioPanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InventarioPanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InventarioPanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActivar;
    private javax.swing.JButton btnDesactivar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnRegresar;
    private javax.swing.JComboBox<Categoria> categoriaSeleccionadaId;
    private javax.swing.JCheckBox chkReceta;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtDescripcion;
    private javax.swing.JTextField txtFoto;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtPrecio;
    // End of variables declaration//GEN-END:variables
}
