package views;
import Models.LoginResponse;
import java.awt.Color;
import java.awt.Image;
import javax.swing.*;

public class AdminPanel extends javax.swing.JFrame {

    private Object lblImagen;
    
    private LoginResponse usuarioLogueado;
    public AdminPanel(LoginResponse usuario) {
        initComponents();
        getContentPane().setBackground(Color.WHITE);
        setLocationRelativeTo(null);
        
        this.usuarioLogueado = usuario;
        
        ajustarImagen();
        activarMenu();
        
        setTitle("Panel Administrador - " + usuario.getUsuarioNombre());
        
        lblBienvenida.setText("Bienvenido " + usuario.getUsuarioNombre());
    }
    
    private void ajustarImagen() {

        java.net.URL url = getClass().getResource("/resources/pharmaOne.png");

        if (url == null) {
            System.out.println("No se encontró la imagen");
            return;
        }

        ImageIcon icon = new ImageIcon(url);

        Image imagenEscalada = icon.getImage().getScaledInstance(
                lblImage.getWidth(),
                lblImage.getHeight(),
                Image.SCALE_SMOOTH);

        lblImage.setIcon(new ImageIcon(imagenEscalada));
    }
    
    private void activarMenu() {
        
        lblProveedores.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblInventario.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblEmpleados.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblCompras.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        lblProveedores.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                new Proveedores(usuarioLogueado).setVisible(true);
                dispose();
            }
        });

        lblInventario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                new InventarioPanel(usuarioLogueado).setVisible(true);
                dispose();
            }
        });

        lblEmpleados.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                new Empleados(usuarioLogueado).setVisible(true);
                dispose();
            }
        });

        lblCompras.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                new ComprasPanel(usuarioLogueado).setVisible(true);
                dispose();
            }
        });
        cerrarSesion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                new Login().setVisible(true);
                dispose();
            }
        });
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblProveedores = new javax.swing.JLabel();
        lblInventario = new javax.swing.JLabel();
        lblEmpleados = new javax.swing.JLabel();
        lblCompras = new javax.swing.JLabel();
        cerrarSesion = new javax.swing.JLabel();
        lblImage = new javax.swing.JLabel();
        lblBienvenida = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocation(new java.awt.Point(0, 0));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(93, 115, 126));

        lblProveedores.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblProveedores.setForeground(new java.awt.Color(255, 255, 253));
        lblProveedores.setText("Proveedores");

        lblInventario.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblInventario.setForeground(new java.awt.Color(255, 255, 255));
        lblInventario.setText("Inventario");

        lblEmpleados.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblEmpleados.setForeground(new java.awt.Color(255, 255, 255));
        lblEmpleados.setText("Empleados");

        lblCompras.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblCompras.setForeground(new java.awt.Color(255, 255, 255));
        lblCompras.setText("Compras");

        cerrarSesion.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        cerrarSesion.setForeground(new java.awt.Color(255, 255, 255));
        cerrarSesion.setText("Cerrar Sesion");
        cerrarSesion.setName("cerrarSesion"); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblCompras, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(lblProveedores, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblInventario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblEmpleados, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(cerrarSesion))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(lblProveedores)
                .addGap(44, 44, 44)
                .addComponent(lblInventario)
                .addGap(42, 42, 42)
                .addComponent(lblEmpleados)
                .addGap(51, 51, 51)
                .addComponent(lblCompras)
                .addGap(42, 42, 42)
                .addComponent(cerrarSesion)
                .addContainerGap(198, Short.MAX_VALUE))
        );

        cerrarSesion.getAccessibleContext().setAccessibleName("cerrarSesion");

        lblImage.setMaximumSize(new java.awt.Dimension(30, 30));
        lblImage.setMinimumSize(new java.awt.Dimension(30, 30));
        lblImage.setName("lblImage"); // NOI18N
        lblImage.setPreferredSize(new java.awt.Dimension(1065, 1024));

        lblBienvenida.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        lblBienvenida.setForeground(new java.awt.Color(93, 115, 126));
        lblBienvenida.setText("jLabel5");
        lblBienvenida.setName("lblBienvenida"); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(lblImage, javax.swing.GroupLayout.PREFERRED_SIZE, 466, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblBienvenida, javax.swing.GroupLayout.PREFERRED_SIZE, 409, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(lblImage, javax.swing.GroupLayout.PREFERRED_SIZE, 403, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(lblBienvenida)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblImage.getAccessibleContext().setAccessibleName("lblImage");
        lblBienvenida.getAccessibleContext().setAccessibleName("lblBienvenida");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel cerrarSesion;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblBienvenida;
    private javax.swing.JLabel lblCompras;
    private javax.swing.JLabel lblEmpleados;
    private javax.swing.JLabel lblImage;
    private javax.swing.JLabel lblInventario;
    private javax.swing.JLabel lblProveedores;
    // End of variables declaration//GEN-END:variables
}
