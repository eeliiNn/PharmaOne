package views;

import Models.Compra;
import Models.DetalleCompra;
import Models.LoginResponse;
import Models.Producto;
import Models.Proveedor;
import com.google.gson.Gson;
import java.awt.Color;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import services.Api;


public class ComprasPanel extends javax.swing.JFrame {
    private List<DetalleCompra> listaDetalles = new ArrayList<>();
    private DefaultTableModel model;
    LoginResponse usuarioLogueado;
    
    public ComprasPanel(LoginResponse usuario) {
        initComponents();
        this.usuarioLogueado = usuario;
        getContentPane().setBackground(Color.WHITE);
        setLocationRelativeTo(null);
        
        JScrollPane scroll = new JScrollPane(CompraPanel);

        scroll.setVerticalScrollBarPolicy(
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

        scroll.setHorizontalScrollBarPolicy(
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        setContentPane(scroll);
        
        model = new DefaultTableModel(
                new Object[][]{},
                new String[]{
                    "ProductoId", "Cantidad", "PrecioCompra",
                    "Lote", "Vencimiento", "SubTotal"
                }
        ) {
            @Override
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };
        
        tablaDetalles.setModel(model);
        cargarProveedores();
        cargarProductos();
        lblTotal.setText("Total: $0");
    }
    
    private void cargarProveedores() {
        try {
            String json = Api.get("proveedor/listar");
            Gson gson = new Gson();
            Proveedor[] proveedores = gson.fromJson(json, Proveedor[].class);

            cmbProveedor.removeAllItems();

            for (Proveedor p : proveedores) {
                cmbProveedor.addItem(p);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void cargarProductos() {
        try {
            String json = Api.get("producto/listar");
            Gson gson = new Gson();
            Producto[] productos = gson.fromJson(json, Producto[].class);

            cmbProducto.removeAllItems();

            for (Producto p : productos) {
                cmbProducto.addItem(p);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        CompraPanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        btnAgregar = new javax.swing.JButton();
        cmbProveedor = new javax.swing.JComboBox<>();
        cmbProducto = new javax.swing.JComboBox<>();
        txtCantidad = new javax.swing.JTextField();
        txtPrecio = new javax.swing.JTextField();
        txtLote = new javax.swing.JTextField();
        txtFecha = new javax.swing.JTextField();
        btnEliminar = new javax.swing.JButton();
        btnRegresar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaDetalles = new javax.swing.JTable();
        lblTotal = new javax.swing.JLabel();
        btnRegistrar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        CompraPanel.setBackground(new java.awt.Color(252, 255, 253));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(93, 115, 126));
        jLabel1.setText("Proveedor:");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(93, 115, 126));
        jLabel2.setText("Producto:");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(93, 115, 126));
        jLabel3.setText("Cantidad:");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(93, 115, 126));
        jLabel4.setText("Precio:");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(93, 115, 126));
        jLabel5.setText("Lote: ");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(93, 115, 126));
        jLabel6.setText("Fecha:");

        btnAgregar.setBackground(new java.awt.Color(93, 115, 126));
        btnAgregar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnAgregar.setForeground(new java.awt.Color(255, 255, 255));
        btnAgregar.setText("Agregar");
        btnAgregar.setName("btnAgregar"); // NOI18N
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        cmbProveedor.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(93, 115, 126)));
        cmbProveedor.setName("cmbProveedor"); // NOI18N

        cmbProducto.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(93, 115, 126)));
        cmbProducto.setName("cmbProducto"); // NOI18N

        txtCantidad.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(93, 115, 126)));
        txtCantidad.setName("txtCantidad"); // NOI18N

        txtPrecio.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(93, 115, 126)));
        txtPrecio.setName("txtPrecio"); // NOI18N

        txtLote.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(93, 115, 126)));
        txtLote.setName("txtLote"); // NOI18N

        txtFecha.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(93, 115, 126)));
        txtFecha.setName("txtFecha"); // NOI18N

        btnEliminar.setBackground(new java.awt.Color(102, 0, 0));
        btnEliminar.setForeground(new java.awt.Color(255, 255, 255));
        btnEliminar.setText("Eliminar");
        btnEliminar.setName("btnEliminar"); // NOI18N
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnRegresar.setBackground(new java.awt.Color(102, 0, 0));
        btnRegresar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnRegresar.setForeground(new java.awt.Color(255, 255, 255));
        btnRegresar.setText("X");
        btnRegresar.setBorder(null);
        btnRegresar.setName("btnRegresar"); // NOI18N
        btnRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresarActionPerformed(evt);
            }
        });

        tablaDetalles.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablaDetalles.setName("tablaDetalles"); // NOI18N
        jScrollPane1.setViewportView(tablaDetalles);
        tablaDetalles.getAccessibleContext().setAccessibleName("tablaDetalles");

        lblTotal.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblTotal.setForeground(new java.awt.Color(93, 115, 126));
        lblTotal.setText("jLabel1");
        lblTotal.setName("lblTotal"); // NOI18N

        btnRegistrar.setBackground(new java.awt.Color(93, 115, 126));
        btnRegistrar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnRegistrar.setForeground(new java.awt.Color(255, 255, 255));
        btnRegistrar.setText("Registrar");
        btnRegistrar.setName("btnRegistrar"); // NOI18N
        btnRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout CompraPanelLayout = new javax.swing.GroupLayout(CompraPanel);
        CompraPanel.setLayout(CompraPanelLayout);
        CompraPanelLayout.setHorizontalGroup(
            CompraPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CompraPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(CompraPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(CompraPanelLayout.createSequentialGroup()
                        .addGroup(CompraPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(CompraPanelLayout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(cmbProveedor, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(CompraPanelLayout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(cmbProducto, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(CompraPanelLayout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(txtCantidad))
                            .addGroup(CompraPanelLayout.createSequentialGroup()
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(txtPrecio))
                            .addGroup(CompraPanelLayout.createSequentialGroup()
                                .addGroup(CompraPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 95, Short.MAX_VALUE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addGroup(CompraPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtLote)
                                    .addGroup(CompraPanelLayout.createSequentialGroup()
                                        .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(btnEliminar)))))
                        .addGap(30, 30, 30))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, CompraPanelLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnRegresar, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 446, Short.MAX_VALUE)))
            .addGroup(CompraPanelLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnRegistrar, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        CompraPanelLayout.setVerticalGroup(
            CompraPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CompraPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnRegresar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(CompraPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(cmbProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(CompraPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(cmbProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(CompraPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(CompraPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(CompraPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtLote, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(CompraPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEliminar))
                .addGap(18, 18, 18)
                .addComponent(btnAgregar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(CompraPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTotal)
                    .addComponent(btnRegistrar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btnAgregar.getAccessibleContext().setAccessibleName("btnAgregar");
        cmbProveedor.getAccessibleContext().setAccessibleName("cmbProveedor");
        cmbProducto.getAccessibleContext().setAccessibleName("cmbProducto");
        txtCantidad.getAccessibleContext().setAccessibleName("txtCantidad");
        txtPrecio.getAccessibleContext().setAccessibleName("txtPrecio");
        txtPrecio.getAccessibleContext().setAccessibleDescription("");
        txtLote.getAccessibleContext().setAccessibleName("txtLote");
        txtFecha.getAccessibleContext().setAccessibleName("txtFecha");
        btnEliminar.getAccessibleContext().setAccessibleName("btnEliminar");
        lblTotal.getAccessibleContext().setAccessibleName("lblTotal");
        btnRegistrar.getAccessibleContext().setAccessibleName("btnRegistrar");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(CompraPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(CompraPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistrarActionPerformed
        // TODO add your handling code here:
        if (listaDetalles.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Agregue al menos un producto");
            return;
        }

        try {

            Proveedor proveedor = (Proveedor) cmbProveedor.getSelectedItem();

            Compra compra = new Compra();
            compra.setProveedorId(proveedor.getProveedorId());
            compra.setDetalles(listaDetalles);

            Gson gson = new Gson();
            String json = gson.toJson(compra);

            String response = Api.post("compra/crear", json);

            JOptionPane.showMessageDialog(this, response);

            listaDetalles.clear();
            model.setRowCount(0);
            actualizarTotal();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al registrar compra");
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnRegistrarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        // TODO add your handling code here:
        int fila = tablaDetalles.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione una fila para eliminar");
            return;
        }

        listaDetalles.remove(fila);
        model.removeRow(fila);

        actualizarTotal();
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresarActionPerformed
        // TODO add your handling code here:
        this.dispose();
        new AdminPanel(usuarioLogueado).setVisible(true);
    }//GEN-LAST:event_btnRegresarActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        // TODO add your handling code here:
        try {
            Producto producto = (Producto) cmbProducto.getSelectedItem();
            int cantidad = Integer.parseInt(txtCantidad.getText());
            double precio = Double.parseDouble(txtPrecio.getText());
            String lote = txtLote.getText();
            String fecha = txtFecha.getText();

            if (cantidad <= 0 || precio <= 0 || lote.isEmpty() || fecha.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Datos inválidos");
                return;
            }

            LocalDate hoy = LocalDate.now();
            LocalDate fechaVenc = LocalDate.parse(fecha);

            if (fechaVenc.isBefore(hoy)) {
                JOptionPane.showMessageDialog(this,
                    "La fecha de vencimiento no puede ser pasada");
                return;
            }

            for (DetalleCompra d : listaDetalles) {
                if (d.getProductoId() == producto.getProductoId() &&
                    d.getNumeroLote().equalsIgnoreCase(lote)) {

                    JOptionPane.showMessageDialog(this,
                        "Ese lote ya fue agregado para este producto");
                    return;
                }
            }

            DetalleCompra detalle = new DetalleCompra();
            detalle.setProductoId(producto.getProductoId());
            detalle.setCantidad(cantidad);
            detalle.setPrecioCompra(precio);
            detalle.setNumeroLote(lote);
            detalle.setFechaVencimiento(fecha);

            listaDetalles.add(detalle);

            double subtotal = cantidad * precio;

            model.addRow(new Object[]{
                producto.getNombre(),
                cantidad,
                precio,
                lote,
                fecha,
                subtotal
            });

            actualizarTotal();
            limpiarCamposDetalle();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error en datos");
        }
    }//GEN-LAST:event_btnAgregarActionPerformed
    
    private void actualizarTotal() {
        double total = 0;
        for (DetalleCompra d : listaDetalles) {
            total += d.getCantidad() * d.getPrecioCompra();
        }
        lblTotal.setText("Total: $" + total);
    }
    
    private void limpiarCamposDetalle() {
        txtCantidad.setText("");
        txtPrecio.setText("");
        txtLote.setText("");
        txtFecha.setText("");
    }
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel CompraPanel;
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnRegistrar;
    private javax.swing.JButton btnRegresar;
    private javax.swing.JComboBox<Producto> cmbProducto;
    private javax.swing.JComboBox<Proveedor> cmbProveedor;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblTotal;
    private javax.swing.JTable tablaDetalles;
    private javax.swing.JTextField txtCantidad;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtLote;
    private javax.swing.JTextField txtPrecio;
    // End of variables declaration//GEN-END:variables
}
